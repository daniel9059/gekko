| abc | def |
| --- | --- |
| bar | foo |
| baz | boo |
    a simple
      *indented* code block

   | abc | def |
   | --- | --- |
   | bar | foo |
   | baz | boo |
    a simple
      *indented* code block
