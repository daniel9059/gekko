---
renderExact: true
---
```js
const value = 42;
```

    const value = 42;

Code blocks contain trailing new line.
