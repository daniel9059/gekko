### Example 1

<!-- comment -->

### Example 2

<!---->

### Example 3

<!-- -->

### Example 4

<!-- - -->

### Example 5

<!-- -- -->

### Example 6

<!-- --->

### Example 7

<!----->

### Example 8

<!------>

### Example 9

<!-- My favorite operators are > and <!-->

### Example 10

<!-- multi
line	
comment
-->

### Example 11

   <!-- indented comment -->

    <!-- too much indentation -->

### Example 12

<!--> not a comment -->

<!---> not a comment -->

<!-- <!-- not a comment? --> -->