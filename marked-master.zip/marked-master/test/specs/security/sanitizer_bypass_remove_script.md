---
sanitize: true
sanitizer: () => ''
---
AAA<script> <img <script> src=x onerror=alert(1) />BBB
