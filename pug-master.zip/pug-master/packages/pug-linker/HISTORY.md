1.0.1 / 2016-08-26
==================

  * Update to `pug-walk@^1.0.0`

1.0.0 / 2016-06-02
==================

  * Mark as stable
  * Make unexpected blocks errors
