declare module 'toml' {
  export function parse(input: string): any;
}
